import { View, Image, Text, Button, StyleSheet } from 'react-native';
import * as FileSystem from 'expo-file-system';
import { saveMemory } from '../utils/storage';
import { useNavigation } from '@react-navigation/native';

export default function PreviewScreen({ route }) {
  const { uri, text, location } = route.params;
  const navigation = useNavigation();

  const handleSave = async () => {
    const fileName = uri.split('/').pop();
    const newPath = FileSystem.documentDirectory + fileName;
    await FileSystem.moveAsync({ from: uri, to: newPath });

    await saveMemory({
      uri: newPath,
      text,
      location,
      date: new Date()
    });

    navigation.navigate('Gallery');
  };

  return (
    <View style={styles.container}>
      <Image source={{ uri }} style={styles.preview} />
      <Text style={styles.text}>{text}</Text>
      <Text>Ubicación: {location.coords.latitude}, {location.coords.longitude}</Text>
      <Button title="Guardar" onPress={handleSave} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  preview: { width: '100%', height: 400 },
  text: { marginVertical: 10 },
});
