import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const getColor = (fechaEntregaStr) => {
  const fechaEntrega = new Date(fechaEntregaStr);
  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0); // Resetear las horas para comparaciones exactas
  fechaEntrega.setHours(0, 0, 0, 0); // Resetear las horas para comparaciones exactas

  if (fechaEntrega < hoy) return '#f28f8f'; // Rojo pastel para pasadas
  if (fechaEntrega.getTime() === hoy.getTime()) return '#9cd99c'; // Verde pastel para hoy
  return '#6c8ccf'; // Azul pastel para futuras
};

export default function HomeScreen() {
  const navigation = useNavigation();
  const [tareas, setTareas] = useState([]);

  const agregarTarea = (nuevaTarea) => {
    const tareaConColor = {
      ...nuevaTarea,
      color: getColor(nuevaTarea.fechaEntrega), // Asignar color basado en la fecha
    };
    setTareas([...tareas, tareaConColor]);
  };

  const editarTarea = (id) => {
    const tareaEditada = tareas.find((tarea) => tarea.id === id);
    if (tareaEditada) {
      navigation.navigate('AddTask', { tarea: tareaEditada, onAdd: actualizarTarea });
    }
  };

  const actualizarTarea = (tareaActualizada) => {
    setTareas((prevTareas) =>
      prevTareas.map((tarea) =>
        tarea.id === tareaActualizada.id ? { ...tarea, ...tareaActualizada } : tarea
      )
    );
  };

  const borrarTarea = (id) => {
    setTareas(tareas.filter((tarea) => tarea.id !== id)); // Elimina la tarea por su id
  };

  const renderItem = ({ item }) => (
    <View style={[styles.item, { backgroundColor: item.color }]}>
      <Text style={styles.nombre}>{item.nombre}</Text>
      <Text>{item.materia}</Text>
      <Text>Entrega: {new Date(item.fechaEntrega).toDateString()}</Text>
      <TouchableOpacity
        style={styles.botonEditar}
        onPress={() => editarTarea(item.id)}
      >
        <Text style={styles.botonTexto}>Editar</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.botonBorrar}
        onPress={() => borrarTarea(item.id)}
      >
        <Text style={styles.botonTexto}>Borrar</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      {tareas.length === 0 ? (
        <Text style={styles.mensaje}>No hay tareas registradas aún.</Text>
      ) : (
        <FlatList
          data={tareas}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
        />
      )}

      <TouchableOpacity
        style={styles.botonFlotante}
        onPress={() => navigation.navigate('AddTask', { onAdd: agregarTarea })}
      >
        <Text style={styles.mas}>＋</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fffaf5', // Fondo pastel claro
  },
  mensaje: {
    marginTop: 20,
    textAlign: 'center',
    color: '#555',
    fontSize: 16,
  },
  item: {
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 1 },
    shadowRadius: 4,
    elevation: 3,
  },
  nombre: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4b4b4b',
  },
  botonFlotante: {
    position: 'absolute',
    bottom: 30,
    right: 30,
    backgroundColor: '#6c8ccf', // Azul pastel para el botón flotante
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowOffset: { width: 2, height: 2 },
    shadowRadius: 4,
    elevation: 5,
  },
  mas: {
    color: '#fff',
    fontSize: 30,
    lineHeight: 32,
  },
  botonEditar: {
    marginTop: 12,
    backgroundColor: '#f3bdb6', // Rosa pastel
    padding: 10,
    borderRadius: 6,
    alignItems: 'center',
  },
  botonBorrar: {
    marginTop: 12,
    backgroundColor: '#f28f8f', // Rojo pastel para borrar
    padding: 10,
    borderRadius: 6,
    alignItems: 'center',
  },
  botonTexto: {
    color: '#fff',
    fontSize: 16,
  },
});
