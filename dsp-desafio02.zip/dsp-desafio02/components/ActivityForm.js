import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';

const ActivityForm = ({ onAdd, onCancel, onLogout }) => {
  const [name, setName] = useState('');
  const [date, setDate] = useState('');
  const [category, setCategory] = useState('');
  const [team, setTeam] = useState('');
  const [time, setTime] = useState('');

  const handleSubmit = () => {
    if (!name || !date || !category || !time) {
      alert('Por favor complete todos los campos.');
      return;
    }
    const formattedDate = date.split('/').reverse().join('-');
    onAdd({ name, category, team, date: formattedDate, time });
  };

  return (
    <View style={styles.container}>
      <TextInput
        placeholder="Nombre de la actividad"
        value={name}
        onChangeText={setName}
        style={styles.input}
      />
      <TextInput
        placeholder="Materia o categoría"
        value={category}
        onChangeText={setCategory}
        style={styles.input}
      />
      <TextInput
        placeholder="Nombre del equipo"
        value={team}
        onChangeText={setTeam}
        style={styles.input}
      />
      <TextInput
        placeholder="Fecha (YYYY/MM/DD)"
        value={date}
        onChangeText={setDate}
        style={styles.input}
        keyboardType="numeric"
      />
      <TextInput
        placeholder="Hora"
        value={time}
        onChangeText={setTime}
        style={styles.input}
      />
      <Button title="Guardar" onPress={handleSubmit} />
      <Button title="Cancelar" onPress={onCancel} color="red" />
      <Button title="Cerrar Sesión" onPress={onLogout} color="red" />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#f2f2f2',
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 8,
    fontSize: 16,
  },
});

export default ActivityForm;
