import React, { useState, useEffect } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LoginScreen from './components/LoginScreen';
import ActivityForm from './components/ActivityForm';
import ActivityList from './components/ActivityList';

export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [users, setUsers] = useState({});
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      const storedUsers = await AsyncStorage.getItem('users');
      const storedCurrentUser = await AsyncStorage.getItem('currentUser');
      if (storedUsers) setUsers(JSON.parse(storedUsers));
      if (storedCurrentUser) setCurrentUser(storedCurrentUser);
    };
    loadData();
  }, []);

  const saveUsers = async (newUsers) => {
    setUsers(newUsers);
    await AsyncStorage.setItem('users', JSON.stringify(newUsers));
  };

  const handleLogin = async (email, password) => {
    if (!email.includes('@')) {
      alert('Ingrese un correo válido.');
      return;
    }
    if (users[email]) {
      if (users[email].password === password) {
        setCurrentUser(email);
        await AsyncStorage.setItem('currentUser', email);
      } else {
        alert('Contraseña incorrecta.');
      }
    } else {
      alert('Usuario no registrado. Use "Registrarse".');
    }
  };

  const handleRegister = async (email, password) => {
    if (!email.includes('@')) {
      alert('Ingrese un correo válido.');
      return;
    }
    if (users[email]) {
      alert('El usuario ya existe.');
    } else {
      const newUsers = { ...users, [email]: { password, activities: [] } };
      await saveUsers(newUsers);
      alert('Usuario registrado. Ahora puede iniciar sesión.');
    }
  };

  const addActivity = async (activity) => {
    const updatedUser = {
      ...users[currentUser],
      activities: [...users[currentUser].activities, activity],
    };
    const newUsers = { ...users, [currentUser]: updatedUser };
    await saveUsers(newUsers);
    setShowForm(false);
  };

  const deleteActivity = async (index) => {
    const updatedActivities = users[currentUser].activities.filter((_, i) => i !== index);
    const newUsers = {
      ...users,
      [currentUser]: { ...users[currentUser], activities: updatedActivities },
    };
    await saveUsers(newUsers);
  };

  const logout = async () => {
    setCurrentUser(null);
    await AsyncStorage.removeItem('currentUser');
  };

  if (!currentUser) {
    return <LoginScreen onLogin={handleLogin} onRegister={handleRegister} />;
  }

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Hola, {currentUser}</Text>
      {showForm ? (
        <ActivityForm onAdd={addActivity} onCancel={() => setShowForm(false)} onLogout={logout} />
      ) : (
        <>
          <Button title="Agregar Actividad" onPress={() => setShowForm(true)} />
          <ActivityList
            activities={users[currentUser].activities}
            onDelete={deleteActivity}
          />
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    paddingTop: 50,
    flex: 1,
    backgroundColor: '#f2f2f2'
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
});
