import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const ActivityList = ({ activities, onDelete }) => {
  const getDateColor = (activityDate) => {
    const currentDate = new Date('2025-04-09'); 
    const activityDateObj = new Date(activityDate);

    const currentDateString = currentDate.toISOString().split('T')[0];
    const activityDateString = activityDateObj.toISOString().split('T')[0];

    if (activityDateString === currentDateString) {
      return 'green'; 
    } else if (activityDateObj > currentDate) {
      return 'blue'; 
    } else {
      return 'red'; 
    }
  };

  return (
    <View style={styles.container}>
      {activities.length === 0 ? (
        <Text>No tienes actividades registradas.</Text>
      ) : (
        activities.map((activity, index) => (
          <View
            key={index}
            style={[styles.activity, { borderColor: getDateColor(activity.date) }]}
          >
            <Text style={styles.activityText}>{activity.name}</Text>
            <Text style={styles.activityText}>Materia: {activity.category}</Text>
            <Text style={styles.activityText}>Equipo: {activity.team}</Text>
            <Text style={styles.activityText}>Fecha: {activity.date}</Text>
            <Text style={styles.activityText}>Hora: {activity.time}</Text>
            <Button title="Eliminar" onPress={() => onDelete(index)} color="red" />
          </View>
        ))
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f2f2f2',
  },
  activity: {
    padding: 10,
    marginBottom: 15,
    borderWidth: 2,
    borderRadius: 5,
  },
  activityText: {
    fontSize: 16,
    marginBottom: 5,
  },
});

export default ActivityList;
