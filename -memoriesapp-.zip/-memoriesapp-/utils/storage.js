// utils/storage.js
import * as FileSystem from 'expo-file-system';

const STORAGE_PATH = FileSystem.documentDirectory + 'memories.json';

export async function saveMemory(memory) {
  let memories = await getMemories();
  memories.push(memory);
  await FileSystem.writeAsStringAsync(STORAGE_PATH, JSON.stringify(memories));
}

export async function getMemories() {
  try {
    const data = await FileSystem.readAsStringAsync(STORAGE_PATH);
    return JSON.parse(data);
  } catch (error) {
    return [];
  }
}
