import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, TouchableOpacity } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';

export default function AddTaskScreen({ route, navigation }) {
  const [nombre, setNombre] = useState('');
  const [materia, setMateria] = useState('');
  const [equipo, setEquipo] = useState('');
  const [fechaEntrega, setFechaEntrega] = useState(new Date());
  const [showPicker, setShowPicker] = useState(false);

  useEffect(() => {
    if (route.params?.tarea) {
      const tareaEditada = route.params.tarea;
      setNombre(tareaEditada.nombre);
      setMateria(tareaEditada.materia);
      setEquipo(tareaEditada.equipo);
      setFechaEntrega(new Date(tareaEditada.fechaEntrega));
    }
  }, [route.params?.tarea]);

  const handleAdd = () => {
    const nuevaTarea = {
      id: route.params?.tarea?.id || Date.now().toString(),
      nombre,
      materia,
      equipo,
      fechaEntrega: fechaEntrega.toISOString(),
    };

    if (route.params?.onAdd) {
      route.params.onAdd(nuevaTarea);
    }

    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Nombre de la actividad</Text>
      <TextInput style={styles.input} value={nombre} onChangeText={setNombre} placeholder="Ej. Exposición de física" placeholderTextColor="#999" />

      <Text style={styles.label}>Materia o categoría</Text>
      <TextInput style={styles.input} value={materia} onChangeText={setMateria} placeholder="Ej. Física" placeholderTextColor="#999" />

      <Text style={styles.label}>Equipo de trabajo</Text>
      <TextInput style={styles.input} value={equipo} onChangeText={setEquipo} placeholder="Ej. Grupo 4" placeholderTextColor="#999" />

      <Text style={styles.label}>Fecha de entrega</Text>
      <TouchableOpacity onPress={() => setShowPicker(true)} style={styles.input}>
        <Text>{fechaEntrega.toDateString()}</Text>
      </TouchableOpacity>

      {showPicker && (
        <DateTimePicker
          value={fechaEntrega}
          mode="date"
          display="default"
          onChange={(event, selectedDate) => {
            setShowPicker(false);
            if (selectedDate) {
              setFechaEntrega(selectedDate);
            }
          }}
        />
      )}

      <Button title="Guardar Tarea" onPress={handleAdd} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fdf6f0', 
    flex: 1,
  },
  label: {
    marginTop: 12,
    fontWeight: '600',
    color: '#4b4b4b',
    fontSize: 16,
  },
  input: {
    borderWidth: 1,
    borderColor: '#d8cfc9',
    backgroundColor: '#fff7f0',
    padding: 12,
    borderRadius: 12,
    marginBottom: 10,
    fontSize: 16,
    color: '#333',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 1 },
    shadowRadius: 2,
    elevation: 2,
  },
  dateInput: {
    borderWidth: 1,
    borderColor: '#d8cfc9',
    backgroundColor: '#fff7f0',
    padding: 12,
    borderRadius: 12,
    marginBottom: 20,
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 1 },
    shadowRadius: 2,
    elevation: 2,
  },
  dateText: {
    fontSize: 16,
    color: '#333',
  },
  button: {
    backgroundColor: '#f2c4c0', 
    padding: 15,
    borderRadius: 15,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 3,
    marginTop: 10,
  },
  buttonText: {
    color: '#4b4b4b',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
