import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

export default function MemoryCard({ memory }) {
  const { uri, text, location } = memory;

  return (
    <View style={styles.card}>
      <Image source={{ uri }} style={styles.image} />
      <Text style={styles.annotation}>{text}</Text>
      <Text style={styles.location}>
        Ubicación: {location?.coords?.latitude?.toFixed(5)}, {location?.coords?.longitude?.toFixed(5)}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    padding: 10,
    margin: 10,
    borderRadius: 10,
    elevation: 2,
  },
  image: {
    width: '100%',
    height: 200,
    borderRadius: 10,
  },
  annotation: {
    marginTop: 10,
    fontWeight: 'bold',
  },
  location: {
    marginTop: 5,
    color: '#555',
  },
});
