import { View, Text, Button, TextInput, StyleSheet } from 'react-native';
import { Camera } from 'expo-camera';
import * as Location from 'expo-location';
import { useNavigation } from '@react-navigation/native';


export default function CameraScreen() {
  const [hasPermission, setHasPermission] = useState(null);
  const [type, setType] = useState(Camera.Constants.Type.back);
  const [text, setText] = useState('');
  const cameraRef = useRef(null);
  const navigation = useNavigation();

  useEffect(() => {
    (async () => {
      const cameraPerm = await Camera.requestCameraPermissionsAsync();
      const locPerm = await Location.requestForegroundPermissionsAsync();
      setHasPermission(cameraPerm.status === 'granted' && locPerm.status === 'granted');
    })();
  }, []);

  const takePicture = async () => {
    if (cameraRef.current) {
      const photo = await cameraRef.current.takePictureAsync();
      const location = await Location.getCurrentPositionAsync({});
      navigation.navigate('Preview', {
        uri: photo.uri,
        text,
        location
      });
    }
  };

  if (hasPermission === null) return <View />;
  if (!hasPermission) return <Text>No se tienen permisos</Text>;

  return (
    <View style={{ flex: 1 }}>
      <Camera ref={cameraRef} style={{ flex: 1 }} type={type}>
        <View style={styles.overlay}>
          <TextInput
            placeholder="Escribe una anotación..."
            value={text}
            onChangeText={setText}
            style={styles.input}
          />
          <Button title="Capturar" onPress={takePicture} />
          <Button title="Cambiar cámara" onPress={() =>
            setType(type === Camera.Constants.Type.back ? Camera.Constants.Type.front : Camera.Constants.Type.back)
          } />
        </View>
      </Camera>
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
    padding: 16,
    backgroundColor: 'transparent',
  },
  input: {
    backgroundColor: 'white',
    padding: 8,
    marginBottom: 10,
  },
});