import { View, FlatList } from 'react-native';
import { getMemories } from '../utils/storage';
import MemoryCard from '../components/MemoryCard';

export default function GalleryScreen() {
  const [memories, setMemories] = useState([]);

  useEffect(() => {
    (async () => {
      const data = await getMemories();
      setMemories(data);
    })();
  }, []);

  return (
    <FlatList
      data={memories}
      keyExtractor={(item, index) => index.toString()}
      renderItem={({ item }) => <MemoryCard memory={item} />}
    />
  );
}
